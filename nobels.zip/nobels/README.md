-----------------------------------------------------------ADD TASK---------------------------------------------------------
![Screenshot (233)](https://github.com/NAHIAN-19/TODO_LIST.github.io/assets/106859103/c9612bde-3d1e-4b24-9d2a-23643e0d3b1b)
---------------------------------------------------------RUNNING TASKS------------------------------------------------------
![Screenshot (234)](https://github.com/NAHIAN-19/TODO_LIST.github.io/assets/106859103/cf6c1538-3105-456a-a78e-35677261709d)
--------------------------------------------------------COMPLETED TASKS-----------------------------------------------------
![Screenshot (235)](https://github.com/NAHIAN-19/TODO_LIST.github.io/assets/106859103/d0ba5ca5-2ca2-4a1a-ac16-7bd1b0d06701)
--------------------------------------------------------ALL CATEGORIES------------------------------------------------------
![Screenshot (236)](https://github.com/NAHIAN-19/TODO_LIST.github.io/assets/106859103/a22ce687-b1fa-4ae5-a94b-2e9abd6b2c75)
-----------------------------------------------------------PROFILE---------------------[------------------------------------
![Screenshot (239)](https://github.com/NAHIAN-19/TODO_LIST.github.io/assets/106859103/60545eff-9f85-4c41-a721-3b9335ffef94)
----------------------------------------------------------DARK MODE---------------------------------------------------------
![Screenshot (240)](https://github.com/NAHIAN-19/TODO_LIST.github.io/assets/106859103/af19a283-cd42-4563-a77e-731084afbcb3)
